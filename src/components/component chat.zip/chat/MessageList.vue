<template>
  <div
    ref="scrollArea"
    class="flex-1 overflow-y-auto px-4 py-3 bg-gray-50"
  >
    <div v-for="(msg, index) in messages" :key="msg.id">
      <!-- Message Bubble -->
      <MessageBubble
        :message="msg"
        :isMe="msg.sender_id === currentUserId"
      />

      <!-- Small spacing between messages -->
      <div class="h-1"></div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick } from 'vue'
import MessageBubble from '../chat/MessageBubble.vue'

const props = defineProps({
  messages: {
    type: Array,
    default: () => [],
  },
  currentUserId: {
    type: Number,
    required: true,
  }
})

const scrollArea = ref(null)

const scrollToBottom = () => {
  nextTick(() => {
    if (scrollArea.value) {
      scrollArea.value.scrollTop = scrollArea.value.scrollHeight
    }
  })
}

// auto-scroll saat pesan berubah
watch(
  () => props.messages,
  () => {
    scrollToBottom()
  },
  { deep: true }
)
</script>
