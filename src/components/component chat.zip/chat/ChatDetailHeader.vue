<template>
  <div
    class="h-16 px-4 flex items-center justify-between border-b bg-white shadow-sm"
  >
    <!-- Left: Avatar + Info -->
    <div class="flex items-center gap-3">
      <div
        class="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-white font-semibold"
      >
        {{ initial }}
      </div>

      <div>
        <h2 class="font-semibold text-gray-800">{{ chat?.name }}</h2>
        <p class="text-xs text-gray-500">
          {{ chat?.status || 'Online' }}
        </p>
      </div>
    </div>

    <!-- Right: Actions -->
    <div class="flex items-center gap-3">
      <button
        @click="$emit('searchMessages')"
        class="p-2 rounded-full hover:bg-gray-100 transition"
      >
        <i class="fa-solid fa-magnifying-glass text-gray-700"></i>
      </button>

      <button
        @click="$emit('menu')"
        class="p-2 rounded-full hover:bg-gray-100 transition"
      >
        <i class="fa-solid fa-ellipsis-vertical text-gray-700"></i>
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue"

const props = defineProps({
  chat: {
    type: Object,
    default: () => null
  }
})

defineEmits(["searchMessages", "menu"])

const initial = computed(() => {
  return props.chat?.name
    ? props.chat.name.charAt(0).toUpperCase()
    : "?"
})
</script>
