<template>
  <div class="flex flex-col h-full w-full relative">

    <!-- HEADER -->
    <ChatDetailHeader
      :chat="activeChat"
      @search="isSearchOpen = true"
    />

    <!-- MESSAGE LIST -->
    <div
      ref="messageListRef"
      class="flex-1 overflow-y-auto bg-neutral-900"
    >
      <MessageList
        :messages="messages"
        :loading="loadingMessages"
      />
    </div>

    <!-- MESSAGE INPUT -->
    <MessageInput
      :onSend="handleSendMessage"
      :disabled="!activeChat"
    />

    <!-- SEARCH PANEL -->
    <transition name="slide-fade">
      <MessageSearchPanel
        v-if="isSearchOpen"
        :chatId="chatId"
        @close="isSearchOpen = false"
        @jump="scrollToMessage"
      />
    </transition>

  </div>
</template>

<script setup>
import { ref, computed, nextTick, onMounted, onBeforeUnmount } from "vue";
import { useRoute } from "vue-router";

import { useChatStore } from "@/stores/chat/useChatStore";
import { useMessageStore } from "@/stores/chat/useMessageStore";

import ChatDetailHeader from "@/components/chat/ChatDetailHeader.vue";
import MessageList from "@/components/chat/MessageList.vue";
import MessageInput from "@/components/chat/MessageInput.vue";
import MessageSearchPanel from "@/components/chat/MessageSearchPanel.vue";

const route = useRoute();
const chatStore = useChatStore();
const messageStore = useMessageStore();

const chatId = Number(route.params.id);

const activeChat = computed(() => chatStore.activeChat);
const messages = computed(() => messageStore.messages);
const loadingMessages = computed(() => messageStore.loading);

const isSearchOpen = ref(false);
const messageListRef = ref(null);

let pollingInterval = null;

// LOAD DATA ----------------------------------------------------

const fetchInitialData = async () => {
  await chatStore.fetchChatById(chatId);
  await messageStore.fetchMessages(chatId);
};

// SEND MESSAGE -------------------------------------------------

const handleSendMessage = async (text) => {
  if (!text || !activeChat.value) return;
  await messageStore.sendMessage(chatId, text);
};

// SCROLL TO MESSAGE DO SEARCH PANEL ----------------------------

const scrollToMessage = async (messageId) => {
  isSearchOpen.value = false;
  await nextTick();

  const target = document.getElementById(`msg-${messageId}`);
  if (target && messageListRef.value) {
    target.scrollIntoView({ behavior: "smooth", block: "center" });
  }
};

// POLLING ------------------------------------------------------

onMounted(async () => {
  await fetchInitialData();

  pollingInterval = setInterval(async () => {
    try {
      await messageStore.fetchMessages(chatId);
    } catch (err) {
      console.error("Polling error:", err);
    }
  }, 1000);
});

onBeforeUnmount(() => {
  if (pollingInterval) clearInterval(pollingInterval);
});
</script>

<style>
.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: all 0.25s ease-in-out;
}
.slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateX(100%);
  opacity: 0;
}
</style>
