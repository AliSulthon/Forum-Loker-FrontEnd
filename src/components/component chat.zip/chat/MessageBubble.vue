<template>
  <div
    class="w-full flex mb-2"
    :class="isMe ? 'justify-end' : 'justify-start'"
  >
    <div
      class="max-w-[75%] px-3 py-2 rounded-2xl text-sm shadow-sm"
      :class="isMe
        ? 'bg-primary-600 text-white rounded-br-sm'
        : 'bg-white text-gray-800 border rounded-bl-sm'
      "
    >
      <p class="whitespace-pre-line break-words">
        {{ message.body }}
      </p>

      <!-- Time -->
      <div
        class="text-[10px] mt-1 opacity-70 flex justify-end"
      >
        {{ message.time }}
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  message: {
    type: Object,
    required: true
  },
  isMe: {
    type: Boolean,
    default: false
  }
})
</script>
