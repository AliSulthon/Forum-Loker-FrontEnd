<template>
  <div class="w-[340px] h-full border-r bg-white flex flex-col">
    
    <!-- HEADER -->
    <div class="h-16 flex items-center justify-between px-4 border-b bg-white">
      <h2 class="text-lg font-semibold text-black">
        Chats
      </h2>

      <button
        class="p-2 rounded-full transition"
        @click="openNewChat"
        title="New Chat"
      >
        <i class="fa-solid fa-message" style="color:#14BEF0; font-size:20px;"></i>
      </button>
    </div>

    <!-- SEARCH -->
    <ChatSearch
      class="border-b"
      @search="(q) => emit('search', q)"
    />

    <!-- CHAT LIST -->
    <div class="flex-1 overflow-y-auto">
      <div v-if="chats.length === 0" class="p-4 text-[#929292] text-center">
        Tidak ada chat
      </div>

      <ChatItem
        v-for="chat in chats"
        :key="chat.id"
        :chat="mapChat(chat)"
        :active="chat.id == activeId"
        @click="selectChat(chat)"
      />
    </div>

    <!-- NEW CHAT PANEL -->
    <NewChatPanel 
      v-model="panelOpen" 
      @created="onCreated"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import ChatSearch from '@/chat/ChatSearch.vue'
import ChatItem from '@/chat/ChatItem.vue'
import NewChatPanel from '@/chat/NewChatPanel.vue'

const props = defineProps({
  chats: Array,
  activeChatId: Number
})

const emit = defineEmits(['select','search'])

const panelOpen = ref(false)

function openNewChat() {
  panelOpen.value = true
}

function onCreated(chat) {
  emit('select', chat)
}
</script>

<style scoped>
button:hover {
  background-color: #E9E9E9; /* hover cerah sesuai desain */
}
</style>
