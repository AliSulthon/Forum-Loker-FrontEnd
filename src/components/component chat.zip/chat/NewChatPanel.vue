<template>
  <transition name="slide-fade">
    <div
      v-if="visible"
      class="fixed inset-0 z-40 flex"
      aria-modal="true"
      role="dialog"
    >
      <!-- backdrop -->
      <div class="fixed inset-0 bg-black/40" @click="close"></div>

      <!-- panel -->
      <aside
        class="ml-auto w-[360px] bg-white shadow-xl h-full flex flex-col"
        @click.stop
      >
        <!-- HEADER -->
        <div class="h-16 flex items-center px-4 border-b">
          <h3 class="text-lg font-semibold text-black">
            Mulai Chat Baru
          </h3>

          <button
            class="ml-auto p-2 rounded hover:bg-[#E9E9E9] transition"
            @click="close"
          >
            <i class="fa-solid fa-xmark" style="color:#14BEF0; font-size:20px;"></i>
          </button>
        </div>

        <!-- SEARCH -->
        <div class="p-4">
          <label class="block text-sm mb-2" style="color:#929292;">
            Cari user
          </label>
          <div class="flex gap-2">
            <input
              v-model="q"
              @input="onSearchInput"
              @keydown.enter.prevent="doSearch"
              placeholder="Cari berdasarkan username / nama"
              class="flex-1 border rounded px-3 py-2 outline-none focus:ring-2"
              style="border-color:#C6C6C6;"
            />

            <button
              class="px-3 py-2 rounded text-white transition"
              style="background-color:#2AA8FF;"
              @click="doSearch"
            >
              Cari
            </button>
          </div>
        </div>

        <!-- LIST -->
        <div class="flex-1 overflow-y-auto">
          <div v-if="loading" class="p-4">
            <div class="animate-pulse space-y-2">
              <div class="h-4 bg-gray-200 rounded w-3/4"></div>
              <div class="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>

          <div
            v-else-if="users.length === 0"
            class="p-4 text-center"
            style="color:#929292;"
          >
            Tidak ada user
          </div>

          <ul v-else class="divide-y">
            <li
              v-for="user in users"
              :key="user.id"
              class="p-3 hover:bg-[#F4F4F4] flex items-center gap-3 cursor-pointer transition"
              @click="selectUser(user)"
            >
              <img
                :src="user.photo || '/images/avatar-placeholder.png'"
                class="w-10 h-10 rounded-full object-cover"
                alt="avatar"
              />

              <div class="flex-1">
                <div class="text-sm font-medium text-black">
                  {{ user.fullname || user.username }}
                </div>
                <div class="text-xs" style="color:#929292;">
                  {{ user.username }}
                </div>
              </div>

              <div class="text-sm font-medium" style="color:#14BEF0;">
                Chat
              </div>
            </li>
          </ul>
        </div>

        <!-- FOOTER -->
        <div class="p-3 border-t text-sm" style="color:#929292;">
          <div v-if="error" class="text-red-600">
            {{ error }}
          </div>
          <div v-else class="text-xs">
            Klik user untuk membuat chat baru. Jika chat sudah ada, otomatis membuka chat tersebut.
          </div>
        </div>
      </aside>
    </div>
  </transition>
</template>

<script setup>
import { ref } from 'vue';
import axios from '@/services/api';
import { useRouter } from 'vue-router';
import { useChatStore } from '@/stores/chat';

const props = defineProps({
  modelValue: { type: Boolean, default: false },
});

const emit = defineEmits(['update:modelValue', 'created']);

const visible = ref(props.modelValue);
const q = ref('');
const users = ref([]);
const loading = ref(false);
const error = ref(null);

const router = useRouter();
const chatStore = useChatStore();

watch(
  () => props.modelValue,
  (v) => {
    visible.value = v;
    if (v) {
      // optional: load default users
      doSearch();
    }
  }
);

function close() {
  visible.value = false;
  emit('update:modelValue', false);
}

let searchTimer = null;
function onSearchInput() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    doSearch();
  }, 400);
}

async function doSearch() {
  loading.value = true;
  error.value = null;
  users.value = [];

  try {
    // NOTE: backend endpoint users/search may not exist; try /users?q=... first.
    // Adjust endpoint to your backend (e.g. /search/users) if needed.
    const res = await axios.get('/users', { params: { q: q.value } });
    users.value = res.data?.data || res.data || [];
  } catch (err) {
    // fallback: try search/users
    try {
      const res2 = await axios.get('/search/users', { params: { q: q.value } });
      users.value = res2.data?.data || res2.data || [];
    } catch (err2) {
      console.error('user search error', err2);
      error.value = 'Gagal mencari user. Coba lagi.';
    }
  } finally {
    loading.value = false;
  }
}

async function selectUser(user) {
  try {
    // create chat via store - expects payload { user_id }
    const payload = { user_id: user.id };
    const chat = await chatStore.createChat(payload);

    // emit event so parent can react (e.g. set active chat)
    emit('created', chat);

    // close panel
    close();

    // navigate to chat detail (route path assumed: /chats/:id)
    router.push({ name: 'chat.detail', params: { chatId: chat.id } });
  } catch (err) {
    console.error('createChat failed', err);
    error.value = err?.response?.data?.message || 'Gagal membuat chat';
  }
}
</script>

<style scoped>
.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: all 220ms ease;
}
.slide-fade-enter-from {
  transform: translateX(10px);
  opacity: 0;
}
.slide-fade-enter-to {
  transform: translateX(0);
  opacity: 1;
}
.slide-fade-leave-from {
  transform: translateX(0);
  opacity: 1;
}
.slide-fade-leave-to {
  transform: translateX(10px);
  opacity: 0;
}
</style>
