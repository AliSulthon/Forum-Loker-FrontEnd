<template>
  <div class="flex flex-col items-center justify-center text-center h-full select-none">

    <!-- Icon Heartbeat / Placeholder -->
    <div class="w-20 h-20 mb-4">
      <svg 
        viewBox="0 0 24 24"
        fill="none"
        stroke="#14BEF0"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1 7.8 7.8 7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z"/>
      </svg>
    </div>

    <!-- Title -->
    <h2 class="text-[#000000] font-semibold text-xl mb-2">
      Select a chat to start messaging
    </h2>

    <!-- Caption -->
    <p class="text-[#929292] text-sm max-w-xs leading-relaxed">
      Your messages will appear here once you choose a conversation from the left.
    </p>

  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
