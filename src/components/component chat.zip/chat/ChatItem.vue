<template>
  <div
    class="flex items-center gap-3 px-4 py-3 cursor-pointer select-none border-b
           hover:bg-gray-100 transition"
    :class="active ? 'bg-primary-50' : 'bg-white'"
    @click="$emit('click')"
  >
    <!-- Avatar -->
    <div
      class="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center text-white font-semibold text-lg"
    >
      {{ chatInitial }}
    </div>

    <!-- Content -->
    <div class="flex-1 min-w-0">
      <div class="flex justify-between items-center">
        <h3
          class="font-semibold text-gray-800 truncate"
        >
          {{ chat.name }}
        </h3>

        <span class="text-xs text-gray-500 whitespace-nowrap">
          {{ chat.last_message_time || '' }}
        </span>
      </div>

      <p
        class="text-sm text-gray-600 truncate"
      >
        {{ chat.last_message || 'Tidak ada pesan' }}
      </p>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  active: {
    type: Boolean,
    default: false,
  },
})

const chatInitial = computed(() => {
  return props.chat.name
    ? props.chat.name.charAt(0).toUpperCase()
    : '?'
})
</script>
