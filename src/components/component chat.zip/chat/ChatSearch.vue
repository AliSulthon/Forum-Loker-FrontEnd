<template>
  <div class="p-3 bg-white">
    <div
      class="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-100 focus-within:ring-2 ring-primary-300 transition"
    >
      <i class="fa-solid fa-magnifying-glass text-gray-500"></i>

      <input
        v-model="query"
        type="text"
        class="flex-1 bg-transparent outline-none text-sm"
        placeholder="Cari chat..."
        @input="emitSearch"
      />

      <button
        v-if="query"
        @click="clear"
        class="text-gray-400 hover:text-gray-600 transition"
      >
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const query = ref('')

const emit = defineEmits(['search'])

const emitSearch = () => {
  emit('search', query.value)
}

const clear = () => {
  query.value = ''
  emit('search', '')
}
</script>
