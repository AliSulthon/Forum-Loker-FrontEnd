<template>
  <div class="h-screen flex bg-gray-100 text-sm">

    <!-- SIDEBAR CHAT LIST -->
    <aside class="w-[340px] border-r bg-white flex flex-col">

      <!-- Header -->
      <ChatHeader
        class="flex-shrink-0"
        title="Chats"
        @refresh="reload"
        @settings="openSettings"
      />

      <!-- Search -->
      <div class="px-3">
        <ChatSearch @search="onSearch" />
      </div>

      <!-- Chat List -->
      <div class="flex-1 overflow-auto">
        <div v-if="loading" class="p-4">
          <MessageLoader />
        </div>

        <div v-else>
          <div v-if="chats.length === 0" class="p-6 text-center text-gray-500">
            Tidak ada percakapan — mulai chat baru
          </div>

          <ChatItem
            v-for="chat in chats"
            :key="chat.id"
            :chat="mapChatForItem(chat)"
            :active="chat.id === selectedId"
            @click="selectChat(chat)"
          />
        </div>
      </div>

      <!-- Create Chat Button -->
      <div class="p-3 border-t">
        <button
          class="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-primary-600 text-white shadow hover:bg-primary-700 transition"
          @click="createChat"
        >
          <i class="fa-solid fa-plus"></i>
          New Chat
        </button>
      </div>
    </aside>

    <!-- MAIN CONTENT / RIGHT PANEL -->
    <main class="flex-1 flex flex-col">
      <router-view />
    </main>

  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, computed } from "vue";
import { useRouter } from "vue-router";
import { useChatStore } from "@/stores/chat/useChatStore";

import ChatHeader from "@/components/chat/ChatHeader.vue";
import ChatSearch from "@/components/chat/ChatSearch.vue";
import ChatItem from "@/components/chat/ChatItem.vue";
import MessageLoader from "@/components/chat/MessageLoader.vue";
import ChatEmptyState from "@/components/chat/ChatEmptyState.vue";

const router = useRouter();
const chatStore = useChatStore();

const loading = computed(() => chatStore.loading);
const chats = computed(() => chatStore.chats);
const selectedId = ref(null);

let pollingInterval = null;

// METHODS ------------------------------------------------------

const reload = async () => {
  await chatStore.fetchChats();
};

const onSearch = async (q) => {
  await chatStore.searchChats(q);
};

const selectChat = (chat) => {
  selectedId.value = chat.id;
  router.push({ name: "ChatDetail", params: { id: chat.id } });
};

const createChat = () => {
  router.push({ name: "CreateChat" });
};

const mapChatForItem = (chat) => ({
  id: chat.id,
  name:
    chat.name ||
    (chat.participants?.length
      ? chat.participants[0].user.fullname
      : "Unknown"),
  last_message:
    chat.lastMessage?.text ?? chat.last_message_text ?? "",
  last_message_time:
    chat.lastMessage?.created_at
      ? relativeTime(chat.lastMessage.created_at)
      : chat.updated_at,
  unread_count: chat.unread_count ?? 0,
});

const relativeTime = (iso) => {
  try {
    const d = new Date(iso);
    const now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60) return `${Math.floor(diff)}s`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
    return d.toLocaleDateString();
  } catch {
    return iso;
  }
};

// POLLING ------------------------------------------------------

onMounted(async () => {
  await reload();

  pollingInterval = setInterval(async () => {
    try {
      await chatStore.fetchChats();
    } catch (err) {
      console.error("Polling error:", err);
    }
  }, 4000);
});

onBeforeUnmount(() => {
  if (pollingInterval) clearInterval(pollingInterval);
});
</script>
