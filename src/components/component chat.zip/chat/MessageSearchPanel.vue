<template>
  <div
    class="w-[360px] h-full bg-neutral-900 border-l border-neutral-800 flex flex-col absolute right-0 top-0 z-40 transition-all duration-300"
  >
    <!-- HEADER -->
    <div class="flex items-center px-4 py-3 border-b border-neutral-800">
      <button @click="$emit('close')" class="text-neutral-400 hover:text-white mr-3">
        ←
      </button>
      <h2 class="text-white font-semibold">Search Messages</h2>
    </div>

    <!-- SEARCH INPUT -->
    <div class="p-3">
      <input
        v-model="query"
        @input="handleSearch"
        type="text"
        placeholder="Search..."
        class="w-full px-3 py-2 rounded-md bg-neutral-800 text-white placeholder-neutral-500 focus:outline-none"
      />
    </div>

    <!-- RESULTS -->
    <div class="flex-1 overflow-y-auto">
      <div v-if="loading" class="text-neutral-400 text-center mt-6">
        Searching...
      </div>

      <div v-else-if="results.length === 0 && query.length > 0" class="text-neutral-500 text-center mt-6">
        No messages found
      </div>

      <ul>
        <li
          v-for="msg in results"
          :key="msg.id"
          class="px-4 py-3 border-b border-neutral-800 hover:bg-neutral-800 cursor-pointer"
          @click="jumpTo(msg.id)"
        >
          <p class="text-white text-sm">{{ msg.text }}</p>
          <p class="text-neutral-500 text-xs mt-1">
            {{ formatDate(msg.created_at) }}
          </p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useMessageStore } from "@/stores/chat/useMessageStore";

const props = defineProps({
  chatId: Number,
});

const emit = defineEmits(["close", "jump"]);

const query = ref("");
const loading = ref(false);
const results = ref([]);

const messageStore = useMessageStore();

const handleSearch = async () => {
  if (!query.value.trim()) {
    results.value = [];
    return;
  }

  loading.value = true;
  results.value = await messageStore.searchMessages(props.chatId, query.value);
  loading.value = false;
};

const jumpTo = (messageId) => {
  emit("jump", messageId);
};

const formatDate = (date) => {
  return new Date(date).toLocaleString();
};
</script>
