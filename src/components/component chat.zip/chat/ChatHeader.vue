<template>
  <div class="h-16 px-4 flex items-center justify-between border-b bg-white">
    <!-- Left: Profile / App Title -->
    <h1 class="font-semibold text-lg text-primary-700">
      {{ title }}
    </h1>

    <!-- Right: Buttons -->
    <div class="flex items-center gap-3">
      <button
        @click="$emit('refresh')"
        class="p-2 rounded-full hover:bg-gray-100 transition"
      >
        <i class="fa-solid fa-rotate-right text-gray-600"></i>
      </button>

      <button
        @click="$emit('settings')"
        class="p-2 rounded-full hover:bg-gray-100 transition"
      >
        <i class="fa-solid fa-gear text-gray-600"></i>
      </button>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    default: "Chats"
  }
})

defineEmits(["refresh", "settings"])
</script>
    