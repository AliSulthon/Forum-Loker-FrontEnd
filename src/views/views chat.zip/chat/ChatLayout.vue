<template>
  <div class="h-screen flex bg-[#F5F5F5]">

    <!-- ========== SIDEBAR ========== -->
    <aside class="w-[340px] border-r bg-white flex flex-col">

      <!-- HEADER -->
      <div class="h-16 flex items-center justify-between px-4 border-b bg-[#E9E9E9]">
        <h2 class="text-lg font-semibold text-[#000]">Chats</h2>

        <button
          class="p-2 rounded-full hover:bg-[#E9E9E9] transition"
          @click="openNewChat"
          title="New chat"
        >
          <i class="fa-solid fa-message text-[#14BEF0]"></i>
        </button>
      </div>

      <!-- SEARCH -->
      <ChatSearch @search="onSearch" class="border-b" />

      <!-- CHAT LIST -->
      <div class="flex-1 overflow-y-auto">
        <div v-if="loading" class="p-4 text-gray-500">
          Loading...
        </div>

        <div v-else-if="chats.length === 0" class="p-6 text-center text-gray-500">
          Tidak ada chat — mulai chat baru
        </div>

        <ChatItem
          v-for="chat in mappedChats"
          :key="chat.id"
          :chat="chat"
          :active="chat.id === activeId"
          @click="selectChat(chat)"
        />
      </div>

    </aside>

    <!-- ========== MAIN PANEL ========== -->
    <main class="flex-1 flex flex-col bg-white">
      <router-view />
    </main>

    <!-- PANEL: NEW CHAT -->
    <NewChatPanel
      v-model="panelOpen"
      @created="goToChat"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from "vue";
import { useRouter, useRoute } from "vue-router";

import ChatSearch from "@/components/chat/ChatSearch.vue";
import ChatItem from "@/components/chat/ChatItem.vue";
import NewChatPanel from "@/components/chat/NewChatPanel.vue";

import { useChatStore } from "@/stores/chat/useChatStore";

const router = useRouter();
const route = useRoute();
const chatStore = useChatStore();

const loading = computed(() => chatStore.loading);
const chats = computed(() => chatStore.chats);

// active chat berdasarkan router (lebih benar)
const activeId = computed(() => Number(route.params.id) || null);

// PANEL
const panelOpen = ref(false);
const openNewChat = () => (panelOpen.value = true);

// SEARCH
const onSearch = (q) => chatStore.searchChats(q);

// Mapping chat (BENAR, tidak duplicate)
const mappedChats = computed(() =>
  chats.value.map((chat) => ({
    id: chat.id,
    name:
      chat.name ||
      chat.participants?.[0]?.user?.fullname ||
      chat.participants?.[0]?.user?.username ||
      "Unknown",

    last_message:
      chat.lastMessage?.text ??
      chat.last_message_text ??
      "Tidak ada pesan",

    last_message_time:
      chat.lastMessage?.created_at ??
      chat.updated_at ??
      "",

    unread: chat.unread_count || 0,
  }))
);

// Setelah pilih chat → route ke halaman detail
const selectChat = (chat) => {
  router.push({
    name: "chat.detail",
    params: { id: chat.id },
  });
};

// Setelah new chat dibuat → route ke chat barusan
const goToChat = (chat) => {
  router.push({
    name: "chat.detail",
    params: { id: chat.id },
  });
};

// Auto refresh tiap 5s
let interval = null;
onMounted(async () => {
  await chatStore.fetchChats();
  interval = setInterval(() => chatStore.fetchChats(), 5000);
});
onBeforeUnmount(() => clearInterval(interval));
</script>
